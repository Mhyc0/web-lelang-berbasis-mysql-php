<?php
include 'config.php';

// Ambil id_peserta dari URL
$id_peserta = $_GET['id'];

// Ambil data peserta berdasarkan id
$query = mysqli_query($koneksi, "SELECT * FROM peserta WHERE id_peserta = '$id_peserta'");
$data = mysqli_fetch_array($query);

// Proses update peserta
if (isset($_POST['update'])) {
    $nama_peserta = $_POST['nama_peserta'];
    $username = $_POST['username'];

    mysqli_query($koneksi, "UPDATE peserta SET nama_peserta = '$nama_peserta', username = '$username' WHERE id_peserta = '$id_peserta'");
    header("Location: peserta.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Peserta</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<header>
    <h2>Edit Peserta Lelang</h2>
</header>

<nav>
    <a href="index.php">Beranda</a>
    <a href="barang.php">Barang</a>
    <a href="peserta.php">Peserta</a>
    <a href="tawaran.php">Tawaran</a>
    <a href="hasil.php">Hasil Lelang</a>
</nav>

<div class="container">
    <div class="card">
        <h3>Edit Peserta</h3>
        <form method="POST">
            <p>Nama Peserta:</p>
            <input type="text" name="nama_peserta" value="<?php echo $data['nama_peserta']; ?>" required><br>
            <p>Username:</p>
            <input type="text" name="username" value="<?php echo $data['username']; ?>" required><br><br>
            <button type="submit" name="update">Update</button>
        </form>
    </div>
</div>

</body>
</html>
