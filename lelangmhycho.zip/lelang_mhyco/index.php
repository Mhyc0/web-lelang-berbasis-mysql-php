<?php
// Koneksi database (kalau nanti butuh)
include 'config.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Web Lelang Mhyco</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<header>
    <h2>Selamat Datang di Web Lelang Mhyco</h2>
</header>

<nav>
    <a href="index.php">Beranda</a>
    <a href="barang.php">Barang</a>
    <a href="peserta.php">Peserta</a>
    <a href="tawaran.php">Tawaran</a>
    <a href="hasil.php">Hasil Lelang</a>
</nav>

<div class="container">
<div class="card">
    <h1>Selamat Datang di Web Lelang Mhyco!</h1>
    <p>Selamat datang di Web Lelang Mhyco, tempatnya berburu barang unik lewat sistem lelang online yang seru dan transparan! Di sini, kamu bisa menemukan berbagai barang menarik mulai dari koleksi antik, barang elektronik, hingga barang-barang langka yang bisa jadi milikmu dengan harga terbaik.</p>

    <p>Platform ini dirancang agar mudah digunakan oleh siapa saja. Kamu bisa melihat daftar barang lelang lengkap dengan deskripsi, harga awal, dan gambar. Selain itu, kamu bisa mendaftar sebagai peserta dan ikut bersaing memberikan tawaran harga tertinggi.</p>

    <p>Proses penawaran berlangsung terbuka dan semua peserta bisa melihat tawaran yang masuk. Saat lelang berakhir, sistem kami otomatis menentukan pemenangnya berdasarkan tawaran tertinggi yang tercatat.</p>

    <p>Ayo, jelajahi barang-barang lelang favoritmu sekarang juga! Gunakan menu di atas untuk melihat daftar barang, peserta, memasang tawaran, dan mengetahui hasil lelang. Siap-siap jadi pemenangnya!</p>

    <p><strong>Selamat berlelang dan semoga barang incarannya jatuh ke tangan kamu!</strong></p>
</div>
</div>

</body>
</html>
