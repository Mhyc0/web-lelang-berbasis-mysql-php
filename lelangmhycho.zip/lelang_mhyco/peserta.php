<?php
include 'config.php';

// Proses simpan peserta
if (isset($_POST['simpan'])) {
    $nama = $_POST['nama_peserta'];
    $username = $_POST['username'];

    mysqli_query($koneksi, "INSERT INTO peserta (nama_peserta, username) VALUES ('$nama','$username')");
    header("location:peserta.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar Peserta</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<header>
    <h2>Daftar Peserta Lelang</h2>
</header>

<nav>
    <a href="index.php">Beranda</a>
    <a href="barang.php">Barang</a>
    <a href="peserta.php">Peserta</a>
    <a href="tawaran.php">Tawaran</a>
    <a href="hasil.php">Hasil Lelang</a>
</nav>

<div class="container">

    <div class="card">
        <h3>Tambah Peserta</h3>
        <form method="POST">
            <p>Nama Peserta:</p>
            <input type="text" name="nama_peserta" required>
            <p>Username:</p>
            <input type="text" name="username" required><br><br>
            <button type="submit" name="simpan">Simpan</button>
        </form>
    </div>

    <div class="card">
        <h3>Daftar Peserta</h3>
        <table>
            <tr>
                <th>No</th>
                <th>Nama Peserta</th>
                <th>Username</th>
                <th>Aksi</th>
            </tr>
            <?php
            $no = 1;
            $data = mysqli_query($koneksi, "SELECT * FROM peserta");
            while($d = mysqli_fetch_array($data)){
            ?>
            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo $d['nama_peserta']; ?></td>
                <td><?php echo $d['username']; ?></td>
                <td>
                    <a href="edit_peserta.php?id=<?php echo $d['id_peserta']; ?>" class="action-btn edit-btn">Edit</a>
                    <a href="hapus_peserta.php?id=<?php echo $d['id_peserta']; ?>" class="action-btn delete-btn" onclick="return confirm('Yakin ingin menghapus peserta ini?')">Hapus</a>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>

</div>

<footer>
    <p>&copy; <?php echo date("Y"); ?> Web Lelang Mhyco</p>
</footer>

</body>
</html>
