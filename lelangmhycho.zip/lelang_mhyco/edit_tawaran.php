<?php
include 'config.php';

// Ambil id_tawaran dari URL
$id_tawaran = $_GET['id'];

// Ambil data tawaran berdasarkan id
$query = mysqli_query($koneksi, "SELECT * FROM tawaran WHERE id_tawaran = '$id_tawaran'");
$data = mysqli_fetch_array($query);

// Proses update tawaran
if (isset($_POST['update'])) {
    $harga_tawaran = $_POST['harga_tawaran'];

    mysqli_query($koneksi, "UPDATE tawaran SET harga_tawaran = '$harga_tawaran' WHERE id_tawaran = '$id_tawaran'");
    header("Location: tawaran.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Tawaran</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<header>
    <h2>Edit Tawaran Lelang</h2>
</header>

<nav>
    <a href="index.php">Beranda</a>
    <a href="barang.php">Barang</a>
    <a href="peserta.php">Peserta</a>
    <a href="tawaran.php">Tawaran</a>
    <a href="hasil.php">Hasil Lelang</a>
</nav>

<div class="container">
    <div class="card">
        <h3>Edit Tawaran</h3>
        <form method="POST">
            <p>Harga Tawaran:</p>
            <input type="number" name="harga_tawaran" value="<?php echo $data['harga_tawaran']; ?>" required><br><br>
            <button type="submit" name="update">Update</button>
        </form>
    </div>
</div>

</body>
</html>
