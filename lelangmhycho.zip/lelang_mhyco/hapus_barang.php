<?php
include 'config.php';

$id = $_GET['id'];

// Hapus dulu tawaran yang terkait
mysqli_query($koneksi, "DELETE FROM tawaran WHERE id_barang='$id'");

// Baru hapus barang
mysqli_query($koneksi, "DELETE FROM barang WHERE id_barang='$id'");

header("location:barang.php");
?>
