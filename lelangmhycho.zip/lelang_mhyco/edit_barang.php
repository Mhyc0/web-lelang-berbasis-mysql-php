<?php
include 'config.php';

$id = $_GET['id'];
$data = mysqli_query($koneksi, "SELECT * FROM barang WHERE id_barang='$id'");
$b = mysqli_fetch_array($data);

if (isset($_POST['update'])) {
    $nama_barang = $_POST['nama_barang'];
    $deskripsi = $_POST['deskripsi'];
    $harga_awal = $_POST['harga_awal'];

    // Kalau ada gambar baru
    if ($_FILES['gambar']['name'] != '') {
        $gambar = $_FILES['gambar']['name'];
        $gambar_tmp = $_FILES['gambar']['tmp_name'];
        $gambar_path = 'images/' . $gambar;
        move_uploaded_file($gambar_tmp, $gambar_path);

        mysqli_query($koneksi, "UPDATE barang SET 
            nama_barang='$nama_barang', 
            deskripsi='$deskripsi',
            harga_awal='$harga_awal',
            gambar='$gambar'
            WHERE id_barang='$id'");
    } else {
        // Kalau tidak ada gambar baru
        mysqli_query($koneksi, "UPDATE barang SET 
            nama_barang='$nama_barang', 
            deskripsi='$deskripsi',
            harga_awal='$harga_awal'
            WHERE id_barang='$id'");
    }

    header("location:barang.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Barang</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<header>
    <h2>Edit Barang Lelang</h2>
</header>

<div class="container">
    <div class="card">
        <form method="POST" enctype="multipart/form-data">
            <label>Nama Barang</label>
            <input type="text" name="nama_barang" value="<?php echo $b['nama_barang']; ?>" required><br>

            <label>Deskripsi</label>
            <textarea name="deskripsi" required><?php echo $b['deskripsi']; ?></textarea><br>

            <label>Harga Awal</label>
            <input type="number" name="harga_awal" value="<?php echo $b['harga_awal']; ?>" required><br>

            <label>Gambar Barang</label><br>
            <img src="images/<?php echo $b['gambar']; ?>" width="150"><br>
            <input type="file" name="gambar"><br><small>Kosongkan jika tidak ingin mengganti gambar.</small><br><br>

            <button type="submit" name="update">Simpan Perubahan</button>
        </form>
    </div>
</div>

</body>
</html>
