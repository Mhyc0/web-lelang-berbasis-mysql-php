<?php
include 'config.php';

// Proses simpan tawaran
if (isset($_POST['simpan'])) {
    $id_peserta = $_POST['id_peserta'];
    $id_barang = $_POST['id_barang'];
    $penawaran_harga = $_POST['penawaran_harga'];

    // Debug: Tampilkan nilai penawaran_harga
    echo "Penawaran Harga: " . $penawaran_harga; // Menampilkan harga yang dimasukkan

    // Insert data tawaran ke dalam database
    mysqli_query($koneksi, "INSERT INTO tawaran (id_peserta, id_barang, penawaran_harga) VALUES ('$id_peserta', '$id_barang', '$penawaran_harga')");
    
    // Redirect ke halaman tawaran setelah data disimpan
    header("location:tawaran.php");
    exit(); // Menghentikan eksekusi script lebih lanjut setelah redirect
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Tawaran</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<header>
    <h2>Data Tawaran Lelang</h2>
</header>

<nav>
    <a href="index.php">Beranda</a>
    <a href="barang.php">Barang</a>
    <a href="peserta.php">Peserta</a>
    <a href="tawaran.php">Tawaran</a>
    <a href="hasil.php">Hasil Lelang</a>
</nav>

<div class="container">

    <div class="card">
        <h3>Tambah Tawaran</h3>
        <form method="POST">
            <p>Peserta:</p>
            <select name="id_peserta" required>
                <option value="">-- Pilih Peserta --</option>
                <?php
                $peserta = mysqli_query($koneksi, "SELECT * FROM peserta");
                while($p = mysqli_fetch_array($peserta)){
                    echo "<option value='$p[id_peserta]'>$p[nama_peserta]</option>";
                }
                ?>
            </select>

            <p>Barang:</p>
            <select name="id_barang" required>
                <option value="">-- Pilih Barang --</option>
                <?php
                $barang = mysqli_query($koneksi, "SELECT * FROM barang");
                while($b = mysqli_fetch_array($barang)){
                    echo "<option value='$b[id_barang]'>$b[nama_barang]</option>";
                }
                ?>
            </select>

            <p>Penawaran Harga:</p>
            <!-- Ubah tipe input menjadi text agar bisa menerima angka lebih besar -->
            <input type="text" name="penawaran_harga" required><br><br>

            <button type="submit" name="simpan">Simpan</button>
        </form>
    </div>

    <div class="card">
        <h3>Data Tawaran</h3>
        <table>
            <tr>
                <th>No</th>
                <th>Peserta</th>
                <th>Barang</th>
                <th>Penawaran Harga</th>
                <th>Aksi</th>
            </tr>
            <?php
            $no = 1;
            $data = mysqli_query($koneksi, "SELECT tawaran.*, peserta.nama_peserta, barang.nama_barang 
                                            FROM tawaran 
                                            JOIN peserta ON tawaran.id_peserta = peserta.id_peserta 
                                            JOIN barang ON tawaran.id_barang = barang.id_barang");
            while($d = mysqli_fetch_array($data)){
            ?>
            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo $d['nama_peserta']; ?></td>
                <td><?php echo $d['nama_barang']; ?></td>
                <td>Rp <?php echo number_format($d['penawaran_harga']); ?></td>
                <td>
                    <a href="edit_tawaran.php?id=<?php echo $d['id_tawaran']; ?>" class="action-btn edit-btn">Edit</a>
                    <a href="hapus_tawaran.php?id=<?php echo $d['id_tawaran']; ?>" class="action-btn delete-btn" onclick="return confirm('Yakin ingin hapus tawaran ini?')">Hapus</a>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>

</div>

<footer>
    <p>&copy; <?php echo date("Y"); ?> Web Lelang Mhyco</p>
</footer>

</body>
</html>
