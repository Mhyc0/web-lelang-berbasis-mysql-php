<?php
include 'config.php';

// Ambil id_tawaran dari URL
$id_tawaran = $_GET['id'];

// Hapus tawaran
mysqli_query($koneksi, "DELETE FROM tawaran WHERE id_tawaran = '$id_tawaran'");

header("Location: tawaran.php");
?>
