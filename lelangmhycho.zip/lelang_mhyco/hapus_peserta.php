<?php
include 'config.php';

// Ambil id_peserta dari URL
$id_peserta = $_GET['id'];

// Hapus peserta
mysqli_query($koneksi, "DELETE FROM peserta WHERE id_peserta = '$id_peserta'");

header("Location: peserta.php");
?>
