<?php
include 'config.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hasil Lelang</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<header>
    <h2>Hasil Lelang</h2>
</header>

<nav>
    <a href="index.php">Beranda</a>
    <a href="barang.php">Barang</a>
    <a href="peserta.php">Peserta</a>
    <a href="tawaran.php">Tawaran</a>
    <a href="hasil.php">Hasil Lelang</a>
</nav>

<div class="container">
    <div class="card">
        <h3>Daftar Pemenang Lelang</h3>
        <?php
        // Ambil data harga tawaran tertinggi per barang dan peserta yang menawar
        $query = "
            SELECT b.nama_barang, p.nama_peserta, t.penawaran_harga
            FROM tawaran t
            JOIN barang b ON t.id_barang = b.id_barang
            JOIN peserta p ON t.id_peserta = p.id_peserta
            WHERE t.penawaran_harga = (
                SELECT MAX(t1.penawaran_harga)
                FROM tawaran t1
                WHERE t1.id_barang = t.id_barang
            )
        ";

        $data = mysqli_query($koneksi, $query);

        // Cek apakah data ditemukan
        if (mysqli_num_rows($data) > 0) {
        ?>
        <table border="1" cellpadding="10" cellspacing="0">
            <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Nama Pemenang</th>
                <th>Harga Tertinggi</th>
            </tr>
            <?php
            $no = 1;
            while($d = mysqli_fetch_array($data)){
            ?>
            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo htmlspecialchars($d['nama_barang']); ?></td>
                <td><?php echo htmlspecialchars($d['nama_peserta']); ?></td>
                <td>Rp <?php echo number_format($d['penawaran_harga'], 0, ',', '.'); ?></td>
            </tr>
            <?php } ?>
        </table>
        <?php
        } else {
            echo "<p>Tidak ada data hasil lelang yang ditemukan.</p>";
        }
        ?>
    </div>
</div>

</body>
</html>
