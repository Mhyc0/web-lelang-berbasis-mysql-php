<?php
include 'config.php';

if (isset($_POST['simpan'])) {
    $nama_barang = $_POST['nama_barang'];
    $deskripsi = $_POST['deskripsi'];
    $harga_awal = $_POST['harga_awal'];

    $gambar = $_FILES['gambar']['name'];
    $gambar_tmp = $_FILES['gambar']['tmp_name'];
    $gambar_path = 'images/' . $gambar;
    move_uploaded_file($gambar_tmp, $gambar_path);

    mysqli_query($koneksi, "INSERT INTO barang (nama_barang, deskripsi, harga_awal, gambar) 
                            VALUES ('$nama_barang', '$deskripsi', '$harga_awal', '$gambar')");
    header("location:barang.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar Barang</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<header>
    <h2>Daftar Barang Lelang</h2>
</header>

<nav>
    <a href="index.php">Beranda</a>
    <a href="barang.php">Barang</a>
    <a href="peserta.php">Peserta</a>
    <a href="tawaran.php">Tawaran</a>
    <a href="hasil.php">Hasil Lelang</a>
</nav>

<div class="container">
    <div class="card">
        <h3>Tambah Barang</h3>
        <form method="POST" enctype="multipart/form-data">
            <p>Nama Barang:</p>
            <input type="text" name="nama_barang" required>
            <p>Gambar Barang:</p>
            <input type="file" name="gambar" required>
            <p>Deskripsi Barang:</p>
            <textarea name="deskripsi" required></textarea>
            <p>Harga Awal:</p>
            <input type="number" name="harga_awal" required><br><br>
            <button type="submit" name="simpan">Tambah Barang</button>
        </form>
    </div>

    <div class="card">
        <h3>Daftar Barang</h3>
        <table>
            <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Harga Awal</th>
                <th>Gambar</th>
                <th>Deskripsi</th>
                <th>Aksi</th>
            </tr>
            <?php
            $no = 1;
            $data = mysqli_query($koneksi, "SELECT * FROM barang");
            while($d = mysqli_fetch_array($data)){
            ?>
            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo $d['nama_barang']; ?></td>
                <td>Rp <?php echo number_format($d['harga_awal']); ?></td>
                <td><img src="images/<?php echo $d['gambar']; ?>" width="100"></td>
                <td><?php echo $d['deskripsi']; ?></td>
                <td>
                    <a href="edit_barang.php?id=<?php echo $d['id_barang']; ?>" class="action-btn edit-btn">Edit</a>
                    <a href="hapus_barang.php?id=<?php echo $d['id_barang']; ?>" class="action-btn delete-btn" onclick="return confirm('Yakin ingin hapus barang ini?')">Hapus</a>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>

</div>

<footer>
    <p>&copy; <?php echo date("Y"); ?> Web Lelang Mhyco</p>
</footer>

</body>
</html>
