-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2025 at 04:46 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lelang_mhyco`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_barang` int(11) NOT NULL,
  `nama_barang` varchar(100) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `harga_awal` int(11) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `nama_barang`, `gambar`, `harga_awal`, `deskripsi`) VALUES
(2, 'StikPs2', '20250428_133222.jpg', 65000, 'Stik ini pernah digunakan oleh legenda guitar hero, kondisi masih bagus semua berfungsi minus pemakaian 7 tahun '),
(3, 'Supra Mk4', '167223758jpg-20210409090745.jpg', 1500000000, 'Mobil sport legendaris berwarna biru, Toyota Supra MK4 dengan mesin 2JZ-GTE bertenaga. Cocok buat pecinta kecepatan dan kolektor mobil klasik.'),
(4, 'Nissan SkylineR34', '0ed144271ca8cf1abf8534d590782b53-1024x768.jpg', 1600000000, 'Sport car ikonik dengan mesin turbo bertenaga dan desain agresif. Cocok buat kamu yang suka kecepatan dan tampilan sporty.'),
(5, 'Lukisan el squid', 'fposter,small,wall_texture,product,750x1000.jpg', 1400000, 'Lukisan tampan dan berani melambangkan keberanian dan ketampanan, cocok untuk hiasan rumah mewah dan elegan'),
(6, 'ASUS ROG ASTRAL GeForce RTX 5090 OC 32GB GDDR7', '6cd449ec-1b8b-435b-9c30-2cbe8173defc.png.webp', 70550000, 'NVIDIA GeForce RTX 5090 hadir dengan 32GB GDDR7, 21760 CUDA Core, dan AI Performance hingga 3593 TOPs. Ditenagai PCIe 5.0, kartu grafis ini mendukung resolusi hingga 8K dengan koneksi 2x HDMI 2.1b & 3x DisplayPort 2.1b. Clock speed mencapai 2610 MHz (OC Mode) dan memory speed 28 Gbps di jalur 512-bit. Dilengkapi ARGB AURA SYNC, 3.8-slot desain, dan membutuhkan PSU 1000W. Bonus aksesoris eksklusif ROG di dalam paket.');

-- --------------------------------------------------------

--
-- Table structure for table `peserta`
--

CREATE TABLE `peserta` (
  `id_peserta` int(11) NOT NULL,
  `nama_peserta` varchar(100) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `peserta`
--

INSERT INTO `peserta` (`id_peserta`, `nama_peserta`, `username`) VALUES
(1, 'sucipto', 'sucipGans11'),
(2, 'waluyo', 'waluyo08'),
(3, 'agung', 'gung10'),
(4, 'SatrioEfu', 'satriyabajahytam99'),
(5, 'Cecep', 'ceceppp'),
(6, 'Tatang', 'tatangtiting'),
(7, 'Dadang', 'dang589'),
(8, 'Jaki', 'Jek123'),
(9, 'IpankJabrix', 'pang70');

-- --------------------------------------------------------

--
-- Table structure for table `tawaran`
--

CREATE TABLE `tawaran` (
  `id_tawaran` int(11) NOT NULL,
  `id_barang` int(11) DEFAULT NULL,
  `id_peserta` int(11) DEFAULT NULL,
  `penawaran_harga` bigint(20) DEFAULT NULL,
  `harga_tawaran` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tawaran`
--

INSERT INTO `tawaran` (`id_tawaran`, `id_barang`, `id_peserta`, `penawaran_harga`, `harga_tawaran`) VALUES
(20, 3, 2, 1700000000, NULL),
(21, 3, 8, 2500000000, NULL),
(22, 4, 7, 1800000000, NULL),
(23, 4, 6, 3000000000, NULL),
(24, 6, 3, 80000000, NULL),
(25, 6, 9, 100000000, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `peserta`
--
ALTER TABLE `peserta`
  ADD PRIMARY KEY (`id_peserta`);

--
-- Indexes for table `tawaran`
--
ALTER TABLE `tawaran`
  ADD PRIMARY KEY (`id_tawaran`),
  ADD KEY `id_barang` (`id_barang`),
  ADD KEY `id_peserta` (`id_peserta`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `peserta`
--
ALTER TABLE `peserta`
  MODIFY `id_peserta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tawaran`
--
ALTER TABLE `tawaran`
  MODIFY `id_tawaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tawaran`
--
ALTER TABLE `tawaran`
  ADD CONSTRAINT `tawaran_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`),
  ADD CONSTRAINT `tawaran_ibfk_2` FOREIGN KEY (`id_peserta`) REFERENCES `peserta` (`id_peserta`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
